namespace PRELIM_E3_Assignment_PerezJustineRyu_BSIT32E2.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
